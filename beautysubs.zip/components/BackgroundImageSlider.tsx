import React, { useState, useEffect } from 'react';

const images = [
  'https://images.pexels.com/photos/3763188/pexels-photo-3763188.jpeg',
  'https://images.pexels.com/photos/1130626/pexels-photo-1130626.jpeg',
  'https://images.pexels.com/photos/1382734/pexels-photo-1382734.jpeg',
  'https://images.pexels.com/photos/762020/pexels-photo-762020.jpeg',
];

const BackgroundImageSlider: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const intervalId = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % images.length);
    }, 5000); // Change image every 5 seconds

    return () => clearInterval(intervalId);
  }, []);

  return (
    <>
      <div className="fixed top-0 left-0 w-full h-full -z-20">
        {images.map((image, index) => (
          <div
            key={index}
            className={`absolute top-0 left-0 w-full h-full bg-cover bg-center transition-opacity duration-[1500ms] ease-in-out ${
              index === currentIndex ? 'opacity-100' : 'opacity-0'
            }`}
            style={{ backgroundImage: `url(${image})` }}
          />
        ))}
      </div>
      <div className="fixed top-0 left-0 w-full h-full bg-black/60 -z-10"></div>
    </>
  );
};

export default BackgroundImageSlider;
