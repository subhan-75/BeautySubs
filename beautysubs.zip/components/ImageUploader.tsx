
import React, { useCallback } from 'react';
import type { ImageFile } from '../types';

interface ImageUploaderProps {
  onImageUpload: (imageFile: ImageFile) => void;
}

const ImageUploader: React.FC<ImageUploaderProps> = ({ onImageUpload }) => {
  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files[0]) {
      const file = event.target.files[0];
      onImageUpload({ file, previewUrl: URL.createObjectURL(file) });
    }
  };

  const onDrop = useCallback((event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    if (event.dataTransfer.files && event.dataTransfer.files[0]) {
      const file = event.dataTransfer.files[0];
       if (file.type.startsWith('image/')) {
         onImageUpload({ file, previewUrl: URL.createObjectURL(file) });
       }
    }
  }, [onImageUpload]);

  const onDragOver = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
  };

  return (
    <div className="w-full">
      <label
        htmlFor="file-upload"
        className="relative cursor-pointer bg-gray-800 rounded-lg border-2 border-dashed border-gray-600 hover:border-purple-500 transition-all duration-300 flex flex-col items-center justify-center p-8 text-center"
        onDrop={onDrop}
        onDragOver={onDragOver}
      >
        <div className="space-y-2">
            <svg className="mx-auto h-12 w-12 text-gray-400" stroke="currentColor" fill="none" viewBox="0 0 48 48" aria-hidden="true">
                <path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 4v.01M28 8L20 16m0 0v12m0-12h8m-4-4l-4-4m32 12l-8-8m0 0l-8 8m8-8v12" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            <span className="font-semibold text-purple-400">Upload a file</span>
            <p className="text-xs text-gray-500">or drag and drop</p>
        </div>
        <p className="text-xs text-gray-500 mt-2">PNG, JPG, WEBP up to 10MB</p>
      </label>
      <input id="file-upload" name="file-upload" type="file" className="sr-only" onChange={handleFileChange} accept="image/*" />
    </div>
  );
};

export default ImageUploader;
