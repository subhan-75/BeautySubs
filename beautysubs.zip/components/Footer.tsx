import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900/50 mt-12">
      <div className="container mx-auto px-4 py-6 text-center text-gray-400">
        <p>&copy; {new Date().getFullYear()} BeautySubs. All rights reserved.</p>
        <p className="text-sm mt-1">Powered by Subhan Ahmad</p>
      </div>
    </footer>
  );
};

export default Footer;