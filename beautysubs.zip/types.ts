
export interface ImageFile {
  file: File;
  previewUrl: string;
}
