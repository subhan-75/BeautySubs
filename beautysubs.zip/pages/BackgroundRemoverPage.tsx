import React, { useState } from 'react';
import type { ImageFile } from '../types';
import PageWrapper from '../components/PageWrapper';
import ImageUploader from '../components/ImageUploader';
import LoadingSpinner from '../components/LoadingSpinner';
import { editImage } from '../services/geminiService';

const BackgroundRemoverPage: React.FC = () => {
  const [originalImage, setOriginalImage] = useState<ImageFile | null>(null);
  const [editedImage, setEditedImage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [prompt, setPrompt] = useState<string>('');

  const handleImageUpload = (imageFile: ImageFile) => {
    setOriginalImage(imageFile);
    setEditedImage(null);
    setError(null);
  };

  const handleEdit = async () => {
    if (!originalImage) {
      setError('Please upload an image first.');
      return;
    }
    if (!prompt) {
      setError('Please describe the new background.');
      return;
    }

    setIsLoading(true);
    setError(null);
    setEditedImage(null);

    const finalPrompt = `Change the background of this image to: "${prompt}". Make sure the person is seamlessly integrated into the new background.`;

    try {
      const newImage = await editImage(originalImage.file, finalPrompt);
      setEditedImage(newImage);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleDownload = () => {
    if (!editedImage) return;
    const link = document.createElement('a');
    link.href = editedImage;
    link.download = 'beautysubs-background.png';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <PageWrapper>
      <div className="text-center">
        <h1 className="text-4xl font-bold mb-2 bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-600">Background Changer</h1>
        <p className="text-gray-400 mb-8">Transport your subject to any location with a simple text description.</p>
      </div>

      {!originalImage && <ImageUploader onImageUpload={handleImageUpload} />}

      {originalImage && (
        <div className="space-y-8">
          <div className="grid md:grid-cols-2 gap-8 items-start">
            <div className="text-center">
              <h2 className="text-2xl font-semibold mb-4">Original</h2>
              <img src={originalImage.previewUrl} alt="Original" className="rounded-lg shadow-lg w-full" />
            </div>
            <div className="text-center">
              <h2 className="text-2xl font-semibold mb-4">Result</h2>
              <div className="aspect-square bg-gray-900/70 backdrop-blur-md rounded-lg shadow-lg flex items-center justify-center w-full">
                {isLoading && <LoadingSpinner />}
                {error && <p className="text-red-400 p-4">{error}</p>}
                {editedImage && <img src={editedImage} alt="Edited" className="rounded-lg w-full" />}
                {!isLoading && !editedImage && !error && <p className="text-gray-500">Your edited image will appear here</p>}
              </div>
            </div>
          </div>

          <div className="bg-gray-900/70 backdrop-blur-md p-6 rounded-lg shadow-xl sticky bottom-4">
            <div className="flex flex-col md:flex-row gap-4 items-center">
              <input
                type="text"
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="e.g., 'a sunny beach with palm trees'"
                className="w-full bg-gray-700 border-2 border-gray-600 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-colors"
                disabled={isLoading}
              />
              <button onClick={handleEdit} disabled={isLoading || !prompt} className="w-full md:w-auto px-8 py-3 font-semibold rounded-lg bg-purple-600 hover:bg-purple-700 disabled:bg-purple-800 disabled:cursor-not-allowed transition-colors whitespace-nowrap">
                Change Background
              </button>
            </div>
            <div className="flex justify-center items-center gap-4 mt-4">
              {editedImage && <button onClick={handleDownload} className="px-6 py-2 font-semibold rounded-lg bg-green-600 hover:bg-green-700 transition-colors shadow-md text-white">Download</button>}
              <button onClick={() => {setOriginalImage(null); setEditedImage(null);}} className="text-gray-400 hover:text-white text-sm">Upload another image</button>
            </div>
          </div>
        </div>
      )}
    </PageWrapper>
  );
};

export default BackgroundRemoverPage;