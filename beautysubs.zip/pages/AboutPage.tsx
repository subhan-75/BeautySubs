import React from 'react';
import PageWrapper from '../components/PageWrapper';

const AboutPage: React.FC = () => {
  return (
    <PageWrapper className="max-w-4xl mx-auto">
      <h1 className="text-4xl font-bold text-center mb-6 bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-600">About BeautySubs</h1>
      <div className="space-y-6 text-lg text-gray-300 bg-gray-900/70 backdrop-blur-md p-8 rounded-lg shadow-lg">
        <p>
          BeautySubs is a cutting-edge web application designed to bring the power of professional photo editing to everyone. We believe that creating stunning, high-quality images shouldn't require complex software or years of experience. By leveraging Google's advanced Gemini AI, we've created a suite of intuitive tools that can transform your photos with just a few clicks.
        </p>
        <p>
          Our mission is to democratize creativity. Whether you're a social media influencer looking to make your posts pop, a small business owner needing polished product photos, or just someone who wants to make their personal memories look their best, BeautySubs is here to help.
        </p>
        <h2 className="text-2xl font-bold text-purple-400 pt-4">Our Features</h2>
        <ul className="list-disc list-inside space-y-2">
          <li>
            <strong>AI Image Enhancement:</strong> Automatically improve resolution, remove blur, and adjust lighting and colors to make your subjects look their absolute best.
          </li>
          <li>
            <strong>Intelligent Background Tools:</strong> Seamlessly remove, blur, or completely replace the background of your photos using simple text prompts. Our AI ensures clean edges and realistic results.
          </li>
          <li>
            <strong>User-Friendly Interface:</strong> We've designed a clean, simple, and responsive interface that makes powerful editing accessible on any device.
          </li>
        </ul>
        <p>
          This application is powered by the Gemini 2.5 Flash Image model, allowing for fast and creative image generation and editing.
        </p>
      </div>
    </PageWrapper>
  );
};

export default AboutPage;