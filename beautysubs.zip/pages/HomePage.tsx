import React from 'react';
import { Link } from 'react-router-dom';
import PageWrapper from '../components/PageWrapper';

const HomePage: React.FC = () => {
  return (
    <PageWrapper>
      <div className="text-center py-16 md:py-24">
        <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight mb-4 bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-600">
          Unlock Your Photo's True Potential
        </h1>
        <p className="max-w-2xl mx-auto text-lg md:text-xl text-gray-300 mb-8">
          Harness the power of AI to enhance, transform, and perfect your images. With BeautySubs, professional-quality photo editing is just a click away.
        </p>
        <div className="flex flex-col sm:flex-row justify-center gap-4">
          <Link
            to="/enhancer"
            className="px-8 py-3 font-semibold rounded-lg bg-purple-600 hover:bg-purple-700 transition-all duration-300 transform hover:scale-105 shadow-lg shadow-purple-500/30"
          >
            Enhance Your Image
          </Link>
          <Link
            to="/background-remover"
            className="px-8 py-3 font-semibold rounded-lg bg-gray-700 hover:bg-gray-600 transition-all duration-300 transform hover:scale-105"
          >
            Change Background
          </Link>
        </div>
      </div>

      <div className="mt-20">
        <h2 className="text-3xl font-bold text-center mb-10">See the Magic</h2>
        <div className="grid md:grid-cols-2 gap-8 items-center">
          <div className="bg-gray-900/70 backdrop-blur-md p-4 rounded-lg shadow-xl">
            <h3 className="text-xl font-semibold mb-2 text-center">Before</h3>
            <img src="https://picsum.photos/id/1027/600/400" alt="Before" className="rounded-md" />
          </div>
          <div className="bg-gray-900/70 backdrop-blur-md p-4 rounded-lg shadow-xl">
             <h3 className="text-xl font-semibold mb-2 text-center">After AI Enhancement</h3>
            <img src="https://picsum.photos/id/1027/600/400?grayscale&blur=2" alt="After" className="rounded-md" />
          </div>
        </div>
      </div>
    </PageWrapper>
  );
};

export default HomePage;