import React, { useState } from 'react';
import type { ImageFile } from '../types';
import PageWrapper from '../components/PageWrapper';
import ImageUploader from '../components/ImageUploader';
import LoadingSpinner from '../components/LoadingSpinner';
import { editImage } from '../services/geminiService';

const ImageEnhancerPage: React.FC = () => {
  const [originalImage, setOriginalImage] = useState<ImageFile | null>(null);
  const [editedImage, setEditedImage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [prompt, setPrompt] = useState<string>('');

  const handleImageUpload = (imageFile: ImageFile) => {
    setOriginalImage(imageFile);
    setEditedImage(null);
    setError(null);
  };

  const handleEdit = async (editType: 'enhance' | 'blur' | 'custom') => {
    if (!originalImage) {
      setError('Please upload an image first.');
      return;
    }

    setIsLoading(true);
    setError(null);
    setEditedImage(null);

    let finalPrompt = '';
    switch(editType) {
        case 'enhance':
            finalPrompt = "Enhance this image to high quality. Focus on the person, remove blurs, fill in any missing details, and adjust the photo quality to flatter the person's skin color, making them look beautiful and clear. The output should be a photorealistic high-resolution image.";
            break;
        case 'blur':
            finalPrompt = "Identify the main person in this image. Keep the person perfectly in focus and apply a high-quality, realistic blur to the entire background behind them. The separation between the person and the background should be clean and precise.";
            break;
        case 'custom':
            if (!prompt) {
                setError('Please enter a custom prompt.');
                setIsLoading(false);
                return;
            }
            finalPrompt = prompt;
            break;
    }

    try {
      const newImage = await editImage(originalImage.file, finalPrompt);
      setEditedImage(newImage);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleDownload = () => {
    if (!editedImage) return;
    const link = document.createElement('a');
    link.href = editedImage;
    link.download = 'beautysubs-enhanced.png';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <PageWrapper>
      <div className="text-center">
        <h1 className="text-4xl font-bold mb-2 bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-600">Image Enhancer</h1>
        <p className="text-gray-400 mb-8">Improve quality, blur backgrounds, or give your own creative instructions.</p>
      </div>

      {!originalImage && <ImageUploader onImageUpload={handleImageUpload} />}

      {originalImage && (
        <div className="space-y-8">
            <div className="grid md:grid-cols-2 gap-8 items-start">
                <div className="text-center">
                    <h2 className="text-2xl font-semibold mb-4">Original</h2>
                    <img src={originalImage.previewUrl} alt="Original" className="rounded-lg shadow-lg w-full" />
                </div>
                <div className="text-center">
                    <h2 className="text-2xl font-semibold mb-4">Result</h2>
                    <div className="aspect-square bg-gray-900/70 backdrop-blur-md rounded-lg shadow-lg flex items-center justify-center w-full">
                        {isLoading && <LoadingSpinner />}
                        {error && <p className="text-red-400 p-4">{error}</p>}
                        {editedImage && <img src={editedImage} alt="Edited" className="rounded-lg w-full" />}
                        {!isLoading && !editedImage && !error && <p className="text-gray-500">Your edited image will appear here</p>}
                    </div>
                </div>
            </div>

          <div className="bg-gray-900/70 backdrop-blur-md p-6 rounded-lg shadow-xl sticky bottom-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
              <div className="flex flex-wrap gap-2 justify-center md:justify-start">
                <button onClick={() => handleEdit('enhance')} disabled={isLoading} className="px-5 py-2 font-semibold rounded-lg bg-purple-600 hover:bg-purple-700 disabled:bg-purple-800 disabled:cursor-not-allowed transition-colors">Enhance Quality</button>
                <button onClick={() => handleEdit('blur')} disabled={isLoading} className="px-5 py-2 font-semibold rounded-lg bg-pink-600 hover:bg-pink-700 disabled:bg-pink-800 disabled:cursor-not-allowed transition-colors">Blur Background</button>
                 {editedImage && <button onClick={handleDownload} className="px-5 py-2 font-semibold rounded-lg bg-green-600 hover:bg-green-700 transition-colors">Download</button>}
              </div>
              <div className="flex gap-2">
                <input
                    type="text"
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder="Or type your custom edit..."
                    className="w-full bg-gray-700 border-2 border-gray-600 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-colors"
                    disabled={isLoading}
                />
                <button onClick={() => handleEdit('custom')} disabled={isLoading || !prompt} className="px-5 py-2 font-semibold rounded-lg bg-gray-600 hover:bg-gray-500 disabled:bg-gray-700 disabled:cursor-not-allowed transition-colors">Go</button>
              </div>
            </div>
            <div className="text-center mt-4">
                <button onClick={() => {setOriginalImage(null); setEditedImage(null)}} className="text-gray-400 hover:text-white text-sm">Upload another image</button>
            </div>
          </div>
        </div>
      )}
    </PageWrapper>
  );
};

export default ImageEnhancerPage;